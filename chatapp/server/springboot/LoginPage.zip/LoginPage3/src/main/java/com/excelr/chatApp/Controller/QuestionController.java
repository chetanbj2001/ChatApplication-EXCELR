package com.excelr.chatApp.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.excelr.chatApp.entity.Answer;
import com.excelr.chatApp.entity.Question;
import com.excelr.chatApp.service.QuestionService;


@CrossOrigin(origins = "http://localhost:3000 ")
@RestController
@RequestMapping("/api/chat")
public class QuestionController {

	@Autowired
	private QuestionService questionService;

//	@Autowired
//	private AnswerService answerService;

	@PostMapping("/questions")
	public Question createQuestion(@RequestBody Question question) {
		Answer answer = question.getAnswer();
		answer.setQuestion(question); // Make sure to set the question in the answer
		question.setAnswer(answer);
		return questionService.createQuestion(question);
	}

	@GetMapping("/{id}")
	public Question getQuestion(@PathVariable Long id) {
		return questionService.getQuestionById(id);
	}

	@GetMapping("/questionAll")
	public ResponseEntity<List<Question>> getAllQuestions() {
		List<Question> questions = questionService.getAllQuestions();
		System.out.println("Number of questions: " + questions.size());
		return new ResponseEntity<>(questions, HttpStatus.OK);
	}

}
