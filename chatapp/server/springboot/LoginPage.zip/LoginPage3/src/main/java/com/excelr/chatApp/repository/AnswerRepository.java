package com.excelr.chatApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.excelr.chatApp.entity.Answer;

public interface AnswerRepository extends JpaRepository<Answer, Long>{

}
