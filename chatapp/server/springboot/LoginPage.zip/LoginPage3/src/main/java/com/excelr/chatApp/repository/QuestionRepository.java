package com.excelr.chatApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.excelr.chatApp.entity.Question;



public interface QuestionRepository extends JpaRepository<Question, Long>{

}
