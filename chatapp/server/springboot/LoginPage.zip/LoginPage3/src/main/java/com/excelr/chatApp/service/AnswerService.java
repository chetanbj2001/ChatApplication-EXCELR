package com.excelr.chatApp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.excelr.chatApp.entity.Answer;
import com.excelr.chatApp.repository.AnswerRepository;

@Service
public class AnswerService {

	@Autowired
	private AnswerRepository answerRepository;
	
	public Answer createAnswer(Answer answer) {
		return answerRepository.save(answer);
	}
	
	public Answer getAnswerById(long id) {
		return answerRepository.findById(id).orElse(null);
	}
}
