package com.excelr.chatApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.excelr.chatApp.entity.Question;
import com.excelr.chatApp.repository.QuestionRepository;



@Service
public class QuestionService {

	@Autowired
	private QuestionRepository questionRepository;
	
	
	
	public Question createQuestion(Question question) {
		question.setAnswer(question.getAnswer());
		return questionRepository.save(question);
		
	}
	
	public Question getQuestionById(Long id) {
		return questionRepository.findById(id).orElse(null);
	}
	
	public List<Question> getAllQuestions() {
        return questionRepository.findAll();
    }
}
