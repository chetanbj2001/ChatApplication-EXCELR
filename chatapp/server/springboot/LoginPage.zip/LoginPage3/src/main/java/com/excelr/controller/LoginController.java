package com.excelr.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.excelr.entity.Agent;
import com.excelr.entity.User;

import com.excelr.service.Services;

@RestController
@CrossOrigin(origins = "http://localhost:3000 ")
@RequestMapping("/api/login/")
public class LoginController {
	@Autowired
    private Services service;

    @PostMapping("users")
    public ResponseEntity<String> login(@RequestBody User user) {
        User foundUser = service.findUserByUsername(user.getUsername());
        if (foundUser != null && foundUser.getPassword().equals(user.getPassword())) {
            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }
    
    
    @PostMapping("agents")
    public ResponseEntity<String> login(@RequestBody Agent agent) {
        Agent foundAgent = service.findAgentByAgentname(agent.getAgentname());
        if (foundAgent != null && foundAgent.getPassword().equals(agent.getPassword())) {
            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }
    
   
}
