package com.excelr.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Agent {
	 @Id
	 	@GeneratedValue(strategy = GenerationType.AUTO)
	    private int id;
	    private String agentname;
	    private String password;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getAgentname() {
			return agentname;
		}
		public void setAgentname(String agentname) {
			this.agentname = agentname;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public Agent(int id, String agentname, String password) {
			super();
			this.id = id;
			this.agentname = agentname;
			this.password = password;
		}
		public Agent() {
			
			// TODO Auto-generated constructor stub
		}
	    
	   
	    
}
