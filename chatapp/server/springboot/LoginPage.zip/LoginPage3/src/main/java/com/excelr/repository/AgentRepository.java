package com.excelr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.excelr.entity.Agent;


public interface AgentRepository extends JpaRepository<Agent, String>{
	Agent findAgentByAgentname(String agentname);
}
