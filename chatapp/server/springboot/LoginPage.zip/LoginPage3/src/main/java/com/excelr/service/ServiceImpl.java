package com.excelr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.excelr.entity.Agent;
import com.excelr.entity.User;
import com.excelr.repository.AgentRepository;
import com.excelr.repository.UserRepository;

@Service
public class ServiceImpl  implements Services{
	 @Autowired
	    private UserRepository userRepository;
	 @Autowired
	    private AgentRepository agentRepository;

	@Override
	public User findUserByUsername(String username) {
		 return userRepository.findUserByUsername(username);
	}

	@Override
	public Agent findAgentByAgentname(String agentname) {
		 return agentRepository.findAgentByAgentname(agentname);
	}



	
}
