package com.excelr.service;


import com.excelr.entity.Agent;
import com.excelr.entity.User;

public interface Services {
	User findUserByUsername(String username);
	Agent findAgentByAgentname(String agentname);

}
